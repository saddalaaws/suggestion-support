import json
import sys
sys.path.append('..')
from cdp_tools import RunInfo


with open('cdp_staging.json') as file_obj:
    config_dict = json.load(file_obj)

RunInfo.set_job_env(config_dict['job_env'])
print(RunInfo.is_local())
print(RunInfo.get_country())
print(RunInfo.get_scope())
print(RunInfo.get_account_name())
print(RunInfo.get_franchise_list())
print(RunInfo.get_input_database('ni'))
print(RunInfo.get_input_database('shared'))
print(RunInfo.get_preprocessing_database('ni'))
print(RunInfo.get_preprocessing_database('shared'))
print(RunInfo.get_global_tables_database('ni'))
print(RunInfo.get_storage_bucket())
print(RunInfo.get_input_bucket('ni'))
